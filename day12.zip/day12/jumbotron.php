<style>
    .mys{
        /* background-color: paleturquoise; */
        background-image: url('ball.jpg');
        /* filter: blur(8px);
        -webkit-filter: blur(8px); */
        padding-top: 10px;
        padding-bottom: 10px;
    }
    .jtext {
        color: yellow;
        text-shadow: 2px 2px 4px #000000;
    }
</style>

<div class="jumbotron text-center text-white mys" style="margin-bottom:0">
  <h1 class="jtext">ระบบลงทะเบียน จ่ายเงินช่วยเหลือภาระค่าใช้จ่าย</h1>
  <h3 class="jtext">ในสถานะการแพร่ระบาด covid 19</h3> 
</div>