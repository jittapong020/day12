<?php include_once 'head.php' ?>
<?php include_once 'jumbotron.php';?>
<?php include_once 'navigater.php';?>

<div class="container" style="margin-top:30px">
  <!-- <div class="row"> -->
    <h3>หน้าที่ 3</h3>
    <h3>หน้าที่ 3</h3>
    <h3>หน้าที่ 3</h3>
    <h3>หน้าที่ 3</h3>

    
  <!-- </div> -->
</div>

<?php include_once 'footer.php' ?>

</body>
</html>
