<style>
    .fsty{
        padding-top: 10px;
        padding-bottom: 10px;
    }
</style>

<div class="jumbotron bg-primary text-white fsty" style="margin-bottom:0">
    <div class="row"> 
        <div class="col-sm-6">
            <span >
                © Copyright Reserved to งานพัฒนาหลักสูตรการเรียนการสอน วิทยาลัยเทคนิคชลบุรี
            </span>
        </div>
        <div class="col-sm-6 text-right">
            <span>
                จัดทำโดยแผนกวิชาเทคโนโลยีสารสนเทศ วิทยาลัยเทคนิคชลบุรี
            </span>
        </div>
    </div>
    
    
</div>